#include<iostream>
#include<iomanip>
using namespace std;
int main()
{

    int a[2][1][3] = {{6,5,4},{3,2,1}};

    a[0][0][0] = 10;
    // a[NROW][NCLOL][NPAGE] = 10;

	for (int k=0; k<2; k++)
    {
        for (int j=0; j<1; j++)
        {
            for (int i=0; i<3; i++)
                cout << setw(4) << a[k][j][i];    // cout immediately, continue loop
            cout << endl;
        }
        cout << endl;
    }

    return 0;
}
