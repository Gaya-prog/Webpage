#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    const int NROW = 3;
    const int NCOL = 4;

    int val[NROW][NCOL] = {8,16,9,5,3,15,27,6,14,25,2,10};

	for (int j=0; j<NROW; j++)
	{
		for (int i=0; i<NCOL; i++)
		{
			cout << setw(4) << val[j][i]*10; 
		}
		cout << endl;
	}
	
    cout << endl;


    return 0;
}
