#include<iostream>
using namespace std;
const int N=5;
int change(int []);
int main()
{
    int a[] = {2,18, 1, 27, 16};

    cout << "Before using the function change(), a is: ";
    for(int i=0; i<N; i++)
        cout << a[i] << " ";

    change(a);

    cout << "\n\nAfter using the function change(), a is: ";
    for(int i=0; i<N; i++)
        cout << a[i] << " ";
    cout << endl;
    return 0;
}

int change(int b[])
{
    b[0] = 1;
    b[3] = 2;
}
