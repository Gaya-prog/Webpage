#include<iostream>
using namespace std;
void findSum(int [], int [], int []);
int main()
{
    int a[5] = {2, 18, 1, 27, 16};
    int b[5] = {1,  2, 3,  4,  5};
    int c[5];

    findSum(a,b,c); 

    cout << "The element-wise summation of vectors a and b is" << endl;

    for(int i=0; i<5; i++)
        cout << c[i] << " ";

    return 0;
}

void findSum(int x[], int y[], int z[])
{
	for(int i=0; i<5; i++)
	{	
		z[i] = x[i] + y[i];
	}
}

