#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int main()
{
    const double PI = 22.0/7;   // constant
    
    double x[5] = {0, PI/2, PI, 3*PI/2, 2*PI}, y[5];  // y = cos(x)

    for(int i=0; i<5; i++)
        y[i] = cos(x[i]);   
        
    cout << fixed << showpoint << setprecision(2);

    for(int i=0; i<5; i++)
        cout << "For i=" << i << ", x[i]=" << x[i] << " and cos(x[i])=" << y[i] << endl;

    return 0;
}

