#include<iostream>
#include<iomanip>
using namespace std;

const int NROW = 3;
const int NCOL = 4;
void multiFun(int [][NCOL],int [][NCOL],int [][NCOL]);
int main()
{

    int a[][NCOL] = {8,16,9,5,3,15,27,6,14,25,2,10};
    int b[][NCOL] = {3,15,27,6,8,16,9,5,14,25,2,10};
    int c[NROW][NCOL];

	multiFun(a,b,c);         // function call

	for (int j=0; j<NROW; j++)
	{
		for (int i=0; i<NCOL; i++)
			cout << setw(4) << c[j][i];    // cout immediately, continue loop
		cout << endl;
	}
    cout << endl;


    return 0;
}


void multiFun(int x[NROW][NCOL],int y[NROW][NCOL],int z[NROW][NCOL])
{
	for (int j=0; j<NROW; j++)
		for (int i=0; i<NCOL; i++)
			z[j][i] = x[j][i]*y[j][i];      // calculate one element

}


