#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    const int NROW = 3;
    const int NCOL = 4;

    int a[NROW][NCOL] = {8,16,9,5,3,15,27,6,14,25,2,10};
    int b[NROW][NCOL] = {3,15,27,6,8,16,9,5,14,25,2,10};
    int c[NROW][NCOL];

	for (int j=0; j<NROW; j++)
	{
		for (int i=0; i<NCOL; i++)
		{
			c[j][i] = a[j][i] + b[j][i];   // calculate one element
			cout << setw(4) << c[j][i];    // cout immediately, continue loop
		}
		cout << endl;
	}
	
    cout << endl;


    return 0;
}
