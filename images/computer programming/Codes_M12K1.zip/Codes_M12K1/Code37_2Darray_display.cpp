#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    const int NROW = 3;
    const int NCOL = 4;

//    int val[NROW][NCOL] ;  // declare only

    int val[NROW][NCOL] = {{8,16,9,5},{3,15,27,6},{14,25,2,10}};  // declare and initialise at the same time
	

    cout << "\nDisplay of val array by explicit element"
         << endl << setw(4) << val[0][0] << setw(4) << val[0][1]
         << setw(4) << val[0][2] << setw(4) << val[0][3]
         << endl << setw(4) << val[1][0] << setw(4) << val[1][1]
         << setw(4) << val[1][2] << setw(4) << val[1][3]
         << endl << setw(4) << val[2][0] << setw(4) << val[2][1]
         << setw(4) << val[2][2] << setw(4) << val[2][3];


    cout << "\n\nDisplay of val array using a nested for loop\n";

	for (int j=0; j<NROW; j++)
	{
		for (int i=0; i<NCOL; i++)
		{
			cout << setw(4) << val[j][i]; 
		}
		cout << endl;
	}
	

    cout << endl;


    return 0;
}
