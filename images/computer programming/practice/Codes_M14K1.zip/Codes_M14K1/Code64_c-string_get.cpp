#include <iostream>
using namespace std;
int main()
{
    const int MAXCHARS = 81;
    char str[MAXCHARS], c;

    cout << "Enter a sentence: \n";

    int i=0;
    while(i<MAXCHARS && (c=cin.get()) !='\n')   // \n = newline character (hit Enter button)
    {
        str[i]=c;
        i++;
    }
    str[i] = '\0';   // NULL character --> to indicate it is a string, not a char array

    cout << "The sentence just entered is:\n";
    cout << str << endl;

    return 0;
}

