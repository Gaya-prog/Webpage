#include <iostream>
using namespace std;
int main()
{
    char name[4] = "UKM";
 //   cout << name;
    for (int i=0; i<4; i++)
        cout << name[i];

//    int x[3] = {2,4,8};
//    cout << x < endl;

//    for (int i=0; i<3; i++)
//        cout << x[i];

    return 0;
}
