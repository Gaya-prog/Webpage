#include <iostream>
#include <cstring>
using namespace std;
int main()
{
    char name[4];
    strcpy(name,"UKM");

    cout << name;

    return 0;
}

