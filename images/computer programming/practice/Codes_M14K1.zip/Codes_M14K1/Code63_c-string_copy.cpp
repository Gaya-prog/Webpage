#include <iostream>
using namespace std;
int main()
{
    const int MAXCHARS = 81;
    char str1[MAXCHARS];
    char str2[MAXCHARS];  // '\0'

    cout << "Enter a sentence: ";  // LINEAR
    cin.getline(str1,MAXCHARS);

    int i=0;   // counter
    while (str1[i] != '\0')  // L I N E A R \0
    {
        str2[i] = str1[i];
        i++;
    }
    //str2[i] = '\0';   // str2 = {'L','I','N','E','A','R','\0'}

    cout << str2 << endl;

    return 0;
}
