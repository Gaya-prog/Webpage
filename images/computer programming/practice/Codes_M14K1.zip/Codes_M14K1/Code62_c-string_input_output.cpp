#include <iostream>
//#include <string>
using namespace std;
int main()
{
//    string message;
//    cout << "Please type anything: ";
//    getline(cin,message);

    const int MAXCHARS = 81;
	char message[MAXCHARS]; // an array of chars with enough storage
//							// for a complete string (line)
    cout << "Please type anything: ";
    cin.getline(message,MAXCHARS,'\n');
//
    cout << "The string just entered is:\n"
         << message << endl;

    return 0;
}
