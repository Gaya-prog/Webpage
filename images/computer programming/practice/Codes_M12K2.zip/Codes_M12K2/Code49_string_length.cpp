#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str1 = "Hello";
    string str2 = "Hello there";

    cout << str1.length() << endl;
    cout << str1.size() << endl;
    cout << str2.length() << endl;
    cout << str2.size() << endl;

    return 0;
}

