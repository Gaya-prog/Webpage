#include<iostream>
#include<string>
using namespace std;

int main()
{
    string name = "John Terry";

    cout << name;


    return 0;
}

