#include<iostream>
#include<string>
using namespace std;

int main()
{
	// Seven ways to instantiate (create & initialise) a string object
	string str1;                                   // create an empty string named str1
    string str2("Good morning");
    string str3 = "Hot Dog";
    string str4(str3);                           // string str4 = "Hot Dog;
    string str5(str3, 4);                       // copy str4 starting index 4 until finishes - Dog
    string str6 = "linear";
    string str7(str6, 3, 2); // copy str6 starting from index 3 until index 5 (3 characters) - ear

    cout << "str1 is: " << str1 << endl;
    cout << "str2 is: " << str2 << endl;
    cout << "str3 is: " << str3 << endl;
    cout << "str4 is: " << str4 << endl;
    cout << "str5 is: " << str5 << endl;
    cout << "str6 is: " << str6 << endl;
    cout << "str7 is: " << str7 << endl;

    return 0;
}

