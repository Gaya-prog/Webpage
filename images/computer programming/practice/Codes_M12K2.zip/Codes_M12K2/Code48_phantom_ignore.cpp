#include<iostream>
#include<string>
using namespace std;
int main()
{
    int value;
    string message;

    cout << "Enter a number: ";
    cin  >> value;
    cout << "The number entered is:\n"
         << value << endl;

    cin.ignore();

    cout << "Enter text:\n";
    getline(cin,message);
    cout << "The text entered is: \n"
         << message << endl;

    return 0;
}

