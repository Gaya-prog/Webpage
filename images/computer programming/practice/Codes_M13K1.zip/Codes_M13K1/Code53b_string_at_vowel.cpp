#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "Universiti Kebangsaan Malaysia";
    int n = str.length();// = 29
    int vowelCount = 0;

    for (int i=0; i<n; i++)
    {
        switch(str.at(i))
        {
            case 'a':
            case 'A':
            case 'e':
            case 'E':
            case 'i':
            case 'I':
            case 'o':
            case 'O':
            case 'u':
            case 'U':
                vowelCount++;
            default:
                ;
        }
    }

    cout << "The string: " << str << endl
         << "has " << vowelCount << " vowels" << endl;

    return 0;

}

