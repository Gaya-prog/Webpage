#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "LINEAR PROGRAMMING THEORY";
    string s1, s2, s3;

    int j, k, m, n;

    cout << "The original string is " << str << endl;

    j = str.find('R'); // 1
    cout << " The first position of an 'R' is " << j << endl;

    k = str.find('R',(j+1));  // 1+1=2
    cout << " The next position of an 'R' is " << k << endl;

    m = str.find('R',(k+1));  // 1+1=2
    cout << " The next position of an 'R' is " << m << endl;

    n = str.find('R',(m+1));  // 1+1=2
    cout << " The next position of an 'R' is " << n << endl;

    return 0;
}

