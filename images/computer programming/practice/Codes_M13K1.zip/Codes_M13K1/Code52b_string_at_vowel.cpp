#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "Universiti Kebangsaan Malaysia";
    int n = str.length();// = 29
    int count_a = 0, count_e = 0, count_i = 0, count_o = 0, count_u = 0;
    int vowelCount;

    for (int i=0; i<n; i++)
    {
        switch(str.at(i))
        {
            case 'a':
            case 'A':
                count_a++;
                break;
            case 'e':
            case 'E':
                count_e++;
                break;
            case 'i':
            case 'I':
                count_i++;
                break;
            case 'o':
            case 'O':
                count_o++;
                break;
            case 'u':
            case 'U':
                count_u++;
                break;
            default:
                ;
        }
    }
    vowelCount = count_a + count_e + count_i + count_o + count_u;
    cout << "The string: " << str << endl
         << "has " << vowelCount << " vowels" << endl;
    return 0;
}

