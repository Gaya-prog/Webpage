#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "LINEAR PROGRAMMING THEORY";
    string s1, s2, s3;

    int j, k, m, n;

    cout << "The original string is " << str << endl;

    j = str.find('I'); // 1
    cout << " The first position of an 'I' is " << j << endl;

    k = str.find('I',(j+1));  // 1+1=2
    cout << " The next position of an 'I' is " << k << endl;
//
//    m = str.find("THEORY");
//    cout << " The first location of \"THEORY\" is " << m << endl;
//
//    n = str.find("ING");
//    cout << " The first index of \"ING\" is " << n << endl;

    // now extract three substrings
 //   s1 = str.substr(2,5);  // 2,3,4,5,6
//    s2 = str.substr(19,3); // 19, 20, 21
//    s3 = str.substr(6,8);  // 6,7,8,9,10,11,12,13
//
//    cout << "The substrings extracted are: " << endl
//         << " " << s1 + s2+ s3 << endl;

    return 0;
}

