#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "Counting the number of vowels";
    int n = str.length();// = 29
    int vowelCount = 0;

    for (int i=0; i<n; i++)
    {
        switch(str.at(i))
        {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                vowelCount++;
            default:
                ;
        }
    }

    cout << "The string: " << str << endl
         << "has " << vowelCount << " vowels" << endl;

    return 0;

}

