#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str1 = "Hello";
    string str2 = "Hello there";

    cout << "str1 is: " << str1 << endl;

    cout << "The number of characters in str1 is "
         << str1.length() << endl << endl;

    cout << "str2 is: " << str2 << endl;
    cout << "The number of characters in str2 is "
         << str2.length()<< endl << endl;

    if (str1 < str2)  // relational operators
        cout << str1 << " is less than " << str2 << endl << endl;
    else if (str1 == str2)
        cout << str1 << " is equal to " << str2 << endl << endl;
    else
        cout << str1 << " is greater than " << str2 << endl << endl;

    str1 = str1 + " there world!";
    cout << "After concatenation, str1 contains the characters: "
         << str1 << endl;

    cout << "The length of this string is "
         << str1.length() << endl;

    return 0;
}

