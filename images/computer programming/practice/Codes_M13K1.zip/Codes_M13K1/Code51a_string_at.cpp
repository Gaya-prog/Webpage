#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "Hello there";

    cout << str.at(6);

//    cout << "Using method \"at\", the character at index " << ind << " is " << str.at(ind) << endl;
//    cout << "Using array notation, the character at index " << ind << " is " << str[ind] << endl;
    return 0;
}

