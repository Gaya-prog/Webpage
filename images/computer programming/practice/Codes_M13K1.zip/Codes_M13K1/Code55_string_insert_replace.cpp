#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "This cannot be";
    cout << "The original string is: " << str << endl
         << " and has " << str.length() << " characters." << endl;

    // insert characters
    str.insert(5,"I know ");
    cout << "The string, after insertion, is: " << str << endl
         << " and has " << str.length() << " characters." << endl;

    // replace characters
    str.replace(12, 6, "to");  // 12 .. 17
    cout << "The string, after replacement, is: " << str << endl
         << " and has " << str.length() << " characters." << endl;

    // append characters
    str = str + " correct";
    cout << "The string, after appending, is: " << str << endl
           << " and has " << str.length() << " characters." << endl;

    return 0;
}

