#include<iostream>
#include<string>
using namespace std;
int main()
{
    string str = "Hello there";

    cout << "Using method \"at\", the character is " << str.at(6) << endl;
    cout << "Using array notation, the character is " << str[6] << endl;
    return 0;
}

