#include<iostream>
#include<string>
#include<cctype>
using namespace std;
int main()
{
    string str;

    cout << "Type in any sequence of characters: ";
    getline(cin, str);                              // insert string

    // cycle through all elements of the string
    for (int i=0; i<str.length(); i++)
        str[i] = tolower(str[i]);       // array notation
//        str.at(i) = tolower(str.at(i)); // at method

    cout << "The characters just entered, in lowercase, are: "
         << str << endl;

    return 0;
}

