#include<iostream>
#include<string>
#include<cctype>
using namespace std;
int main()
{
//    cout << int(1) << endl;
//    cout << int("1") << endl;

    cout << isalpha('A') << endl;
    cout << isalpha('a') << endl;
//    cout << isalpha("130") << endl << endl;

    cout << isalnum('A') << endl;
  //  cout << isalnum('130') << endl;
    cout << isalnum('3') << endl << endl;

    cout << isupper('A') << endl;
    cout << isupper('a') << endl << endl;

    cout << islower('A') << endl;
    cout << islower('a') << endl << endl;

    cout << isdigit('A') << endl;
  //  cout << isdigit('-1') << endl;
    cout << isdigit('3') << endl;

    return 0;
}

