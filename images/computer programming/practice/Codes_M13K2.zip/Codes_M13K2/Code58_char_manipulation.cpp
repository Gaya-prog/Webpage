#include<iostream>
#include<string>
#include<cctype>
using namespace std;
int main()
{
    string str = "This -123/ is 567 A ?<6245> Test!";
    char c;
    int nLetters = 0, nDigits = 0, nOthers = 0;  // counters

    // check each character in the string
    for (int i=0; i<str.length(); i++)
    {
        c = str.at(i);

        if(isalpha(c))  // for letter: if letter, TRUE, if not letter, FALSE
            nLetters++;  // nLetters = nLetters + 1
        else if (isdigit(c))
            nDigits++;  // nDigits = nDigits + 1
        else
            nOthers++;

    }

    cout << "The original string is: " << str
         << "\nThis string contains " << str.length()
         << " characters," << " which consist of" << endl
         << "   " << nLetters << " letters" << endl
         << "   " << nDigits << " digits" << endl
         << "   " << nOthers << " other characters." << endl;


    return 0;
}

