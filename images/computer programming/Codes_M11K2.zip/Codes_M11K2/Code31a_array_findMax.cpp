#include<iostream>
using namespace std;
int findMax(int,int);   // function declaration/prototype
int main()
{
    int m, a[5] = {-19,-18,1,27,16}; // array declaration and initialisation simultaneously
                                              // 5 is the no of elements of array named 'a'.
                                              
    m = findMax(a[0],a[1]);
	
	cout << "The smaller number is " << m << endl;

    return 0;
}


int findMax(int x, int y)   // function definition
{
    int z;
    if (x>y)
        z = x;   // z is only a placeholder that holds the smaller number
    else // x<=y
        z = y;
    return z;
}
