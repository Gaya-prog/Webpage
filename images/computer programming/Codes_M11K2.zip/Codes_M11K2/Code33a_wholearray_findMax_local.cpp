#include<iostream>
using namespace std;
int findMax(int [],int);   // function declaration/prototype
int main()
{
	const int N=5;      // local constant     
    int maxnum, a[N] = {2,18, 1, 27, 16}; // array declaration and initialisation simultaneously
                                          // 5 is the no of elements of array named 'a'.
    maxnum = findMax(a,N); //function call

    cout << "The maximum value is " << maxnum << endl;

    return 0;
}

// function definition
int findMax(int b[], int n)                       // function header   
{
	// function body
	int m = b[0]; // 2                     
    for(int i=1; i<n; i++)
        if (m < b[i]) // FALSE
            m = b[i]; // maxnum = a[3] = 27
    return m;
}

