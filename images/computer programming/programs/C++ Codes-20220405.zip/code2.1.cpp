#include <iostream>
using namespace std;

int main ()
{
	int a;
	a=86;
	cout<<"Integer: a = "<<a<<endl;

    float x;
    x=0.02456;
	cout << "Floating number: x = "<<x<<endl;

	double y;
	y=-31.0054236;
    cout<<"Double floating point: y = "<<y<<endl;

	bool p,q,r;

	p=1; q=0; r=4;
    cout<<"Boolean number: p = "<<p<<", q = "<<q<<", r = "<<r<<endl;

    char MyChar;
    MyChar='t';
	cout <<"Character: MyChar is "<<MyChar<<endl;

	char MyString[]="hello world";
	cout<<"String: MyString is "<<MyString<<endl;

	return 0;
}


