//code 2.3


#include <iostream>

using namespace std;

int main ()
{
	int sum,count;

	sum = 0; count = 100;

	cout<<"The value of sum is initially set to " << sum <<endl;

	sum = sum +96;
	cout<<"sum is now " << sum << endl;

	sum += 70;
	cout<<"sum is now " << sum << endl;

	sum += 85;
	cout<<"sum is now " << sum << endl;

	sum += 60;
	cout<<"The final sum is " << sum << endl;

	count++;
	cout<< "count now is "<< count <<endl;

	count++;
	cout<< "count now is "<< count <<endl;

	return 0;
}


