//code 2.4

#include <iostream>

using namespace std;

int main ()
{
	cout << 6 << endl
		 << 18 << endl
		 << 124 << endl
		 << "---\n"
		 << 6+18+124 << endl;
		 
	return 0;
}



