//code 2.5

#include <iostream>
#include <cmath> //mathematical functions
#include <iomanip> //input/output manipulation

using namespace std;

int main ()
{
	int h;
	double t;

	h = 800;
	t = sqrt(2*h/32.2);
	cout<< "It will take "<< t << " second to fall " << h << " feet.\n";


	cout<<fixed<<setprecision(2);
	cout<<"It will take "<< t << " second to fall " << h << " feet.\n";


	return 0;
}



