//Code 4.4

#include <iostream>

using namespace std;

int main()
{
	char marcode;
	
	cout << "Enter a marital code: ";
	cin >> marcode;
	
	if (marcode == 'M')
		cout << "Individual is married." << endl;
	else if (marcode == 'S')
		cout << "Individual is single." << endl;
	else if (marcode == 'D')
		cout << "Individual is divorced." << endl;
	else if (marcode == 'W')
		cout << "Individual is widowed." << endl;
	else
		cout << "An invalid cod was entered." << endl;
		 
	return 0;
}


