#include<iostream>
using namespace std;
int main()
{
    int i=11;
    do
    {
        cout << i << " ";
        i=i+1;
    }while(i<=10);

    return 0;
}
