#include<iostream>
using namespace std;
int main()
{
    for (int i=20; i>=0; i+=-5)
        cout << i << " ";

    return 0;
}
