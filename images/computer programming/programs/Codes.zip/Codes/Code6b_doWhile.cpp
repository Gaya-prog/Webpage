#include<iostream>
using namespace std;
int main()
{
    int i=11;
    while(i<=10)
    {
        cout << i << " ";
        i=i+1;
    }

    return 0;
}
