#include<iostream>
using namespace std;
int main()
{
    for (int i=0; i<=20; i=i+5)
        cout << i << " ";

    return 0;
}
