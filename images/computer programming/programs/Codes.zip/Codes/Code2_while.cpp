#include<iostream>
using namespace std;
int main()
{
    int i=1, n;
    double num, sum=0, ave;

    cout << "How many numbers do you want to insert: ";
    cin  >> n;

    cout << "Please insert your numbers, each separated by a space/enter:" << endl;

    while(i<=n)
    {
        cin >> num;
        sum = sum + num;
        i=i+1;
    }

    ave = sum/n;

    cout << "\nThe sum is " << sum << endl;
    cout << "\nThe average of the numbers is " << ave << endl;


    return 0;
}
