#include<iostream>
using namespace std;
int main()
{
    int i, n;
    double num, sum, ave;

    cout << "How many numbers do you want to insert: ";
    cin  >> n;

    cout << "Please insert your numbers, each separated by a space/enter:" << endl;

    for (i=1; i<=n; i+=1)
    {
        cin >> num;
        sum = sum + num;
    }

    ave = sum/n;

    cout << "\nThe sum is " << sum << endl;
    cout << "\nThe average of the numbers is " << ave << endl;


    return 0;
}
