//Code 5.2

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	double celsius, fahren;
	
	celsius = 5; 		// starting Celsius value
					
	while (celsius <= 50)
	{
		fahren = (9.0/5.0) * celsius + 32.0;
		cout << setw(4) << celsius
			<< setw(13) << fahren << endl;
		celsius = celsius + 5;
	}

		 
	return 0;
}



