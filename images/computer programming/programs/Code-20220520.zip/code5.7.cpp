//Code 5.7

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	const int MAXNUMS = 4;
	int count;
	double num, total;
	
	cout << "\nThis program will ask you to enter " << MAXNUMS << " numbers.\n";
	
		total = 0;
	
	for (count = 1; count <= MAXNUMS; count++ )
	{
		cout << "\nEnter a number: ";
		cin >> num;
		total = total + num;
		cout << "The total is now " << total;	
	}
	
	cout << "\n\nThe final total is " << total << endl;
		 
	return 0;
}



