//Code 5.5

#include <iostream>

using namespace std;

int main()
{
	int count;
	
	for (count = 2; count <= 20; count = count + 2)
		cout << count << " ";
	
/*	count = 2;	
	for (; count <= 20; count = count + 2)
		cout << count << " ";
*/		 
	return 0;
}



