//Code 5.9

#include <iostream>
using namespace std;

int main()
{
	int idNum;
	
	do
	{
		cout << "\nEnter an identification number: ";
		cin >> idNum;
		
		if (idNum < 100 || idNum > 1999)
			cout << "\nAn invalid number was just entered.\n"
				<< "Please check the ID number and reenter.\n";
		else
			break;
	}while (1);
	
	cout << "\nYour identification number is " << idNum << endl;
	
	return 0;
}



