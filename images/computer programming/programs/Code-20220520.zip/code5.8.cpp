//Code 5.8

#include <iostream>
using namespace std;

int main()
{
	const int MAXCOUNT = 5;
	int count;
	double num, total, average;
	
	total = 0;
	
	for (count = 0; count < MAXCOUNT; count++ )
	{
		cout << "\nEnter a number: ";
		cin >> num;
		total = total + num;
		cout << "The total is now " << total;	
	}
	
	average = total/count;
	
	cout << "\n\nThe average of the data entered is " << average << endl;
		 
	return 0;
}



