//Code 5.6

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
	const int MAXNUMS = 10;
	int num;
	cout << endl;
	cout << "NUMBER		SQUARE		CUBE\n" 
		 << "------		------		----\n";
	
	for (num = 1; num <= MAXNUMS; num++)
		cout << setw(3) << num << "		"
			 << setw(3) << num*num << "		"
			 << setw(3) << pow (num,3) << endl;
			 
	return 0;
}



