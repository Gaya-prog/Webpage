#include<iostream>
using namespace std;
int main()
{
    int n=0;
    double num, sum=0, ave;

    cout << "Please insert positive numbers, each separated by a space/enter." << endl;
    cout << "Type any negative number to finish." << endl;

    cin >> num;
    while(num>0)
    {
        sum = sum + num;
        n=n+1;
        cin >> num;
    }

    ave = sum/n;

    cout << "\nThe sum is " << sum << endl;
    cout << "\nThe average of the numbers is " << ave << endl;


    return 0;
}
