#include<iostream>
using namespace std;
const int SENTINEL = -1;
int main()
{
    int n=0;
    double num, sum=0, ave;

    cout << "Please insert positive numbers, each separated by a space/enter." << endl;
    cout << "Hit -1 to finish." << endl;

    cin >> num;
    while(num!=SENTINEL)
    {
        sum = sum + num;
        n=n+1;
        cin >> num;
    }

    ave = sum/n;

    cout << "\nThe sum is " << sum << endl;
    cout << "\nThe average of the numbers is " << ave << endl;


    return 0;
}
