//
//  code3a.cpp: Writing data to a file
//  IO


#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream output;
    output.open ("myoutput.txt");

    output << "This is myoutput.txt file.";

    output.close();


    return 0;
}
