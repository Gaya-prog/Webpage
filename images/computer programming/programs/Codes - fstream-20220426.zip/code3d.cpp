//
//  code3d.cpp: Read data from a file
//  IO
//


#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    //ifstream input;
	//input.open("scores.txt");
    ifstream input ("scores.txt");
    // Read data
    string firstName;
    string mi;
    string lastName;
    int score;
    input >> firstName >> mi >> lastName >> score;
    cout << firstName << " " << mi << " " << lastName << " "
    << score << endl;

    input >> firstName >> mi >> lastName >> score;
    cout << firstName << " " << mi << " " << lastName << " "
    << score << endl;

    input.close();

    cout << "Done" << endl;

    return 0;
}
