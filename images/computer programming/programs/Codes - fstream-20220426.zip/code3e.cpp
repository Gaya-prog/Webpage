//
//  code3e.cpp: fail() and eof()
//  IO
//


#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    // Open a file
    ifstream input;
    input.open("state.txt");

    if (input.fail())
    {
        cout << "File does not exist" << endl;
        cout << "Exit program" << endl;
        return 0;
    }

    // Read data
    string city;

    while (!input.eof()) // Continue if not end of file
    {
        input >> city;
        //cout << city << " ";
    }

    input.close();

    cout << "\nDone" << endl;

    return 0;
}
