//
//  code3c.cpp: Read data from a file
//  IO
//

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream input;
    input.open("input.txt");

    int num1, num2, num3, num4;

    input >> num1 >> num2 >> num3 >> num4;

    cout << num1 << " ";
    cout << num2 << " ";
    cout << num3 << " ";
    cout << num4 << " " << endl;

    input.close();


    return 0;
}
