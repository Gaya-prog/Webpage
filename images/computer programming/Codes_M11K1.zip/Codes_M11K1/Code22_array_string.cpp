#include<iostream>
#include<string>
using namespace std;
int main()
{
    string item[3] = {"bulbs","papers","hammers"};  // string array

    for(int i=0; i<=2; i++)
        cout << item[i] << endl;


    return 0;
}

