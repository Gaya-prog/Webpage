#include<iostream>
using namespace std;
int main()
{
	  //  int prod=1, a[5] = {2,3,4,5,6}; // array declaration and initialisation simultaneously

    double prod=1;
	double a[5] = {98,87,92,79,85}; // array declaration and initialisation simultaneously
                                 // 5 is the no of elements of array named 'a'.

    for(int i=0; i<5; i++)
        prod = prod*a[i];

    cout << "The product of the elements of a is " << prod << endl;




    return 0;
}

