#include<iostream>
using namespace std;
int main()
{
    int minnum, pos, a[5] = {-19,-18,1,27,16}; // array declaration and initialisation simultaneously
                                              // 5 is the no of elements of array named 'a'.
    minnum = a[0];
    pos=i;
    for(int i=1; i<=4; i++)
    {
        if (minnum>a[i])
        {
            minnum=a[i];
            pos=i;
        }
    }
    cout << "The minimum value is " << minnum << endl;
    cout << "which is at position " << pos << " of the array." << endl;




    return 0;
}

