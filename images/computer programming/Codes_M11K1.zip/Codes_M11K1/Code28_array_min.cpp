#include<iostream>
using namespace std;
int main()
{
    int minnum, a[5] = {2,18, 1, 27, 16};

    minnum = a[0]; // 2
    for(int i=1; i<5; i++)
        if (minnum > a[i]) // 1>a[4]=16 FALSE
            minnum = a[i];  // minnum = a[2] = 1

    cout << "The minimum value is " << minnum << endl;

    return 0;
}

