#include<iostream>
using namespace std;
int main()
{
    int maxnum, pos, a[5] = {-19,-18,1,27,16}; // array declaration and initialisation simultaneously
                                              // 5 is the no of elements of array named 'a'.
    maxnum = a[0];
    pos=i;
    for(int i=1; i<=4; i++)
    {
        if (maxnum>a[i])
        {
            maxnum=a[i];
            pos=i;
        }
    }
    cout << "The minimum value is " << maxnum << endl;
    cout << "which is at position " << pos << " of the array." << endl;




    return 0;
}

