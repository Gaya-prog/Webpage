#include<iostream>
using namespace std;
int main()
{
    char grade[6] = {'s','a','m','p','l','e'};  // character array

    for(int i=0; i<=5; i++)
        cout << grade[i];


    return 0;
}

