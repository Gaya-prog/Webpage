#include<iostream>
using namespace std;
int main()
{
    int n;   // size of array to be entered by user
    int a[n];   // array a of size n, where n is entered by the user.

    cout << "How many numbers do you want to enter: ";
    cin  >> n;

    cout << "\nPlease type your number followed by a space/enter/tab:";

    for(int i=0; i<n; i++)
        cin >> a[i];

    cout << "\nYou have entered: ";
    for(int i=0; i<n; i++)
        cout << a[i] << endl;


    return 0;
}

