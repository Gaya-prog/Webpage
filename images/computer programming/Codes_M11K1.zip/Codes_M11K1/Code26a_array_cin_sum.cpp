#include<iostream>
using namespace std;
int main()
{
    int n, sum;

    cout << "How many numbers do you want to enter: ";
    cin  >> n;

    int a[n];   // array a of size n, where n is entered by the user.
    cout << "\nPlease type your number followed by a space/enter/tab:";

    for(int i=0; i<n; i++)
        cin >> a[i];

    cout << "\nYou have entered: ";
    for(int i=0; i<n; i++)
        cout << a[i] << endl;

    sum = 0;
    for(int i=0; i<n; i++)
        sum = sum + a[i];

    cout << "\nThe sum of the numbers that you have entered is " << sum << endl;

    return 0;
}

