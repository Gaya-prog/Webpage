#include<iostream>
using namespace std;
int main()
{
    int index=0, maxnum, a[5] = {2,18,1,27,16}; // array declaration and initialisation simultaneously
                                          // 5 is the no of elements of array named 'a'.
    maxnum = a[0]; // 2
    for(int i=1; i<5; i++)
        if (maxnum< a[i]) // FALSE
        {
        	maxnum = a[i]; // maxnum = a[3] = 27
			index = i;
		}

    cout << "The maximum value is " << maxnum
    	 << " at position " << index << " of the array" << endl;

    return 0;
}

