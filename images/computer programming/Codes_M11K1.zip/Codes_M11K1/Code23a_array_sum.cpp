#include<iostream>
using namespace std;
int main()
{
    int sum, a[5] = {98,87,92,79,85}; // array declaration and initialisation simultaneously
                                 // 5 is the no of elements of array named 'a'.

    sum = a[0] + a[1] + a[2] + a[3] + a[4];

    cout << "The sum of the elements of a is " << sum << endl;




    return 0;
}

