#include<iostream>
using namespace std;
int main()
{
    int a[5];   // array declaration, 5 is the no of elements of array named 'a'.

    a[0] = 98;  // array initialisaton for 1st element of a
    a[1] = 87;  // array initialisaton for 2nd element of a
    a[2] = 92;  // array initialisaton for 3rd element of a
    a[3] = 79;  // array initialisaton for 4th element of a
    a[4] = 85;  // array initialisaton for 5th element of a

    for(int i=1; i<=5; i++)
        cout << a[i] << " ";

}

