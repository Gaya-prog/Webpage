#include<iostream>
using namespace std;
int main()
{
    int a[5];   // array declaration, 5 is the no of elements of the array named 'a'.

    a[0] = 98;  // initialise 1st element of a
    a[1] = 87;  // initialise 2nd element of a
    a[2] = 92;  // initialise 3rd element of a
    a[3] = 79;  // initialise 4th element of a
    a[4] = 85;  // initialise 5th element of a

    cout << a[1] << " " << a[2] << " " << a[3] << " " << a[4] << " " << a[5] << endl;
}

