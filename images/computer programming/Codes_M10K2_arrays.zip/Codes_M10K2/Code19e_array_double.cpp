#include<iostream>
using namespace std;
int main()
{
    int N=5;
    double a[N];   // array declaration, 5 is the no of elements of array named 'a'.

    a[0] = 98.1;  // array initialisaton for 1st element of a
    a[1] = 87.3;  // array initialisaton for 2nd element of a
    a[2] = 92.4;  // array initialisaton for 3rd element of a
    a[3] = 79.7;  // array initialisaton for 4th element of a
    a[4] = 85.9;  // array initialisaton for 5th element of a

    for(int i=0; i<N; i++)
        cout << a[i] << " ";


}

