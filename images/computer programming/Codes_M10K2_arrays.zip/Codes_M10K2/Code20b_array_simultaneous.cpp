#include<iostream>
using namespace std;
int main()
{
    int a[] = {98, 87, 92, 79, 85};  // declare & initialise at the same time

    for(int i=0; i<=4; i++)
        cout << a[i] << " ";
    return 0;
}

