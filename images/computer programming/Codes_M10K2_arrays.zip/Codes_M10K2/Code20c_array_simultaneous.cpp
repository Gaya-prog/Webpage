#include<iostream>
using namespace std;
int main()
{
    int a[5] = {98, 87, 92, 79, 85}; // array declaration and initialisation simultaneously
                                 // 5 is the no of elements of array named 'a'.
    for(int i=0; i<=4; i++)
        cout << "For i= " << i << ", we have a[" << i << "]="<< a[i] << endl;
    return 0;
}

